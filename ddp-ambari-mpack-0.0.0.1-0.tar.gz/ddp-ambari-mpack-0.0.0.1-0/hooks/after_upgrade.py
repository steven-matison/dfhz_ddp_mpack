import smartsense_versioner

if __name__ == "__main__":
  smartsense_versioner.fix_smartsense_versions()